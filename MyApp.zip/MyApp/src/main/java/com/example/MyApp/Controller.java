package com.example.MyApp;

public @interface Controller {

}
