package com.example.MyApp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/**
 * ShuttleController: Handles all web requests for the VIT Shuttle Booking application.
 * This class is annotated with @Controller, making it a Spring-managed bean that handles web traffic.
 *
 * Note: This implementation uses simple in-memory data structures (List/Map) to store and manage
 * routes and bookings without needing a database or external Service/Repository layer.
 */
@Controller
public class ShuttleController {

    // --- Model Classes (Simple Java Records for immutability) ---

    /** Represents a Shuttle Route */
    public record Route(int id, String origin, String destination, List<String> timings) {}

    /** Represents a Confirmed Booking */
    public record Booking(String bookingId, String studentRegNo, Route route, String time, String date) {}

    // --- In-Memory Data Storage ---
    private final List<Booking> confirmedBookings = new ArrayList<>();
    private final Map<Integer, Route> availableRoutes;

    public ShuttleController() {
        // Initialize predefined routes for all students
        availableRoutes = Map.of(
            1, new Route(1, "VIT Main Campus", "Katpadi Railway Station", List.of("06:00 AM", "09:00 AM", "01:00 PM", "05:00 PM")),
            2, new Route(2, "VIT Main Campus", "Bus Stand & Market", List.of("07:30 AM", "12:00 PM", "04:30 PM", "08:00 PM")),
            3, new Route(3, "Ladies Hostel", "Main Campus Gate 1", List.of("07:45 AM", "08:15 AM", "04:00 PM", "06:00 PM")),
            4, new Route(4, "Mens Hostel G-Block", "Tech Park", List.of("08:00 AM", "05:30 PM"))
        );
    }

    // --- Controller Methods ---

    /**
     * Handles the root request (/) and displays the Booking page (booking.html).
     * @param regNo Optional student registration number (simulates user session/authentication).
     * @param model Thymeleaf model to pass data to the view.
     * @return The name of the Thymeleaf template (`booking.html`).
     */
    @GetMapping("/")
    public String showBookingPage(@RequestParam(required = false) String regNo, Model model) {
        // Pass the list of available routes to the frontend
        model.addAttribute("routes", availableRoutes.values());

        // Handle user session based on registration number
        if (regNo != null && !regNo.isEmpty()) {
            final String currentRegNo = regNo.toUpperCase();
            model.addAttribute("currentRegNo", currentRegNo);

            // Filter bookings for the current student
            List<Booking> studentBookings = confirmedBookings.stream()
                    .filter(b -> b.studentRegNo().equals(currentRegNo))
                    .sorted((a, b) -> a.date().compareTo(b.date())) // Sort by date
                    .toList();
            model.addAttribute("studentBookings", studentBookings);
        } else {
            // Default/No login view setup
            model.addAttribute("currentRegNo", null);
            model.addAttribute("studentBookings", List.of());
        }

        // Pass today's date for date picker minimum restriction
        model.addAttribute("today", LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE));
        return "booking"; // Corresponds to src/main/resources/templates/booking.html
    }

    /**
     * Handles the form submission via POST request to create a new booking.
     * @param routeId The ID of the selected route.
     * @param time The selected departure time.
     * @param date The selected travel date.
     * @param regNo The student's registration number.
     * @param redirectAttributes Used to pass success/error messages after redirect (flash attributes).
     * @return Redirects back to the main page, ensuring data freshness.
     */
    @PostMapping("/book")
    public String handleBooking(
            @RequestParam int routeId,
            @RequestParam String time,
            @RequestParam String date,
            @RequestParam String regNo,
            RedirectAttributes redirectAttributes) {

        Route route = availableRoutes.get(routeId);
        final String studentRegNo = regNo.toUpperCase();

        if (route == null || !route.timings().contains(time)) {
            // Data validation failed
            redirectAttributes.addFlashAttribute("error", "Invalid route or time selected. Please try again.");
            return "redirect:/?regNo=" + studentRegNo;
        }

        // 1. Create a unique, readable booking ID
        String bookingId = "VIT" + UUID.randomUUID().toString().substring(0, 5).toUpperCase();

        // 2. Create and store the new booking object
        Booking newBooking = new Booking(bookingId, studentRegNo, route, time, date);
        confirmedBookings.add(newBooking);

        // 3. Set confirmation message
        redirectAttributes.addFlashAttribute("success",
            String.format("Booking confirmed! ID: %s. %s → %s on %s at %s.",
                bookingId, route.origin(), route.destination(), date, time));

        // Redirect back to the main page, maintaining the user's session context
        return "redirect:/?regNo=" + studentRegNo;
    }
}
